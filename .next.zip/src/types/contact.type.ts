export type FormData = {
  name: string;
  email: string;
  message: string;
};